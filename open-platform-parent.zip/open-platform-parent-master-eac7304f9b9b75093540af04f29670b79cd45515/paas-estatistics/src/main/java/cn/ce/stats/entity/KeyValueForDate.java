package cn.ce.stats.entity;

/**
 *
 * @Title: KeyValueForDate.java
 * @Description 日期开始结束时间的工具类
 * @version V1.0
 * @author yang.yu@300.cn
 * @date dat2017年8月30日 time上午8:46:51
 *
 **/
public class KeyValueForDate {

	private String startDate;
	private String endDate;

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

}
