package cn.cd.key;

import org.springframework.stereotype.Controller;

/**
* @Description : 后台密钥管理
* @Author : makangwei
* @Date : 2017年8月18日
*/
@Controller
public class KeyController {

}
