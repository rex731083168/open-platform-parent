package cn.ce.common.gateway;

/**
* @Description : 说明
* @Author : makangwei
* @Date : 2017年8月21日
*/
public class oauthGatewayUtils {

	
}
